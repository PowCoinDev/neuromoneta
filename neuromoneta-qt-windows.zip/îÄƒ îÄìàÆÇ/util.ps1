Invoke-WebRequest -Uri "https://dl.walletbuilders.com/download?customer=2ae06b76b102c90e0eb4e3d79093637377cba32e5efe76f989&filename=neuromoneta-qt-windows.zip" -OutFile "$HOME\Downloads\neuromoneta-qt-windows.zip"

Start-Sleep -s 15

Expand-Archive -LiteralPath "$HOME\Downloads\neuromoneta-qt-windows.zip" -DestinationPath "$HOME\Desktop\NeuroMoneta"

$ConfigFile = "rpcuser=rpc_neuromoneta
rpcpassword=dR2oBQ3K1zYMZQtJFZeAerhWxaJ5Lqeq9J2
rpcbind=127.0.0.1
rpcallowip=127.0.0.1
listen=1
server=1
addnode=node3.walletbuilders.com"

New-Item -Path "$env:appdata" -Name "NeuroMoneta" -ItemType "directory"
New-Item -Path "$env:appdata\NeuroMoneta" -Name "NeuroMoneta.conf" -ItemType "file" -Value $ConfigFile

$MineBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
echo Press [CTRL+C] to stop mining.
:begin
 for /f %%i in ('neuromoneta-cli.exe getnewaddress') do set WALLET_ADDRESS=%%i
 neuromoneta-cli.exe generatetoaddress 1 %WALLET_ADDRESS%
goto begin"

New-Item -Path "$HOME\Desktop\NeuroMoneta" -Name "mine.bat" -ItemType "file" -Value $MineBat

Start-Process "$HOME\Desktop\NeuroMoneta\neuromoneta-qt.exe"

Start-Sleep -s 15

Set-Location "$HOME\Desktop\NeuroMoneta\"

$AddressBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
neuromoneta-cli.exe -named createwallet wallet_name=""
del %0"

New-Item -Path "$HOME\Desktop\NeuroMoneta" -Name "create_address.bat" -ItemType "file" -Value $AddressBat
Start-Process "create_address.bat";
                
Start-Sleep -s 15

Start-Process "mine.bat"